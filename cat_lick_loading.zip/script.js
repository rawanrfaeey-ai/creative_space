window.addEventListener('load', () => {
    const lickSound = document.getElementById('lick-sound');
    const words = document.querySelectorAll('#loading-text span');

    // Start sound after user interaction
    const startSound = () => {
        lickSound.play().catch(err => console.log("Sound blocked:", err));
    };
    document.body.addEventListener('click', startSound, { once: true });
    document.body.addEventListener('touchstart', startSound, { once: true });

    // Step 1: Wait 2 seconds with sparkle intro
    setTimeout(() => {
        let i = 0;
        const lickInterval = setInterval(() => {
            if (i < words.length) {
                words[i].style.opacity = '0';
                lickSound.currentTime = 0;
                lickSound.play().catch(() => {});
                i++;
            } else {
                clearInterval(lickInterval);
                // Step 3: Fade out screen after licking
                setTimeout(() => {
                    document.getElementById('loading-screen').style.opacity = '0';
                    document.getElementById('loading-screen').style.transition = 'opacity 1s ease';
                    setTimeout(() => {
                        document.getElementById('loading-screen').style.display = 'none';
                        document.body.style.background = 'white';
                    }, 1000);
                }, 500);
            }
        }, 800);
    }, 2000);
});
